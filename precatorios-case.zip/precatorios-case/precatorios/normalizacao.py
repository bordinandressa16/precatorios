"""Funções puras de normalização: número de processo, valores, datas e nomes.

Nenhuma função aqui lê arquivos. Todas levantam ``DadoInvalido`` (ou
``DadoAmbiguo``) em vez de "adivinhar", para que quem chama decida o destino
do registro (corrigir, descartar ou mandar para dúvida).
"""
from __future__ import annotations

import re
import unicodedata
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from zoneinfo import ZoneInfo

# Os tribunais citados (TJSP, TRF3, TRT2) estão em horário de Brasília.
# O Brasil não tem horário de verão desde 2019, mas usar o fuso nomeado
# (e não "-03:00" fixo) mantém datas antigas corretas.
FUSO = ZoneInfo("America/Sao_Paulo")

CENTAVOS = Decimal("0.01")


class DadoInvalido(ValueError):
    """O dado não pode ser interpretado."""


class DadoAmbiguo(DadoInvalido):
    """O dado poderia ter mais de uma leitura válida; não escolhemos uma."""


# --------------------------------------------------------------------------
# Número de processo (padrão CNJ: NNNNNNN-DD.AAAA.J.TR.OOOO = 20 dígitos)
# --------------------------------------------------------------------------
def normalizar_processo(texto: object) -> str:
    """Devolve os 20 dígitos do processo, aceitando a forma com ou sem máscara."""
    if not isinstance(texto, str) or not texto.strip():
        raise DadoInvalido("número de processo vazio")
    t = texto.strip()
    if not re.fullmatch(r"[0-9.\-\s]+", t):
        raise DadoInvalido(f"número de processo com caracteres inesperados: {texto!r}")
    digitos = re.sub(r"\D", "", t)
    if len(digitos) != 20:
        raise DadoInvalido(
            f"número de processo com {len(digitos)} dígitos (esperado 20): {texto!r}"
        )
    return digitos


def formatar_processo(digitos: str) -> str:
    """20 dígitos -> NNNNNNN-DD.AAAA.J.TR.OOOO."""
    d = digitos
    return f"{d[:7]}-{d[7:9]}.{d[9:13]}.{d[13]}.{d[14:16]}.{d[16:]}"


def dv_cnj_valido(digitos: str) -> bool:
    """Confere os dígitos verificadores (mod 97, Resolução CNJ 65/2008).

    Atenção: nos arquivos deste case NENHUM dos números passa nesta conferência
    (os dados são fictícios), por isso o pipeline não a usa como critério de
    descarte. Ela existe para ser ligada quando os dados forem reais.
    """
    if not re.fullmatch(r"\d{20}", digitos):
        return False
    sequencial, dv, resto = digitos[:7], digitos[7:9], digitos[9:]
    return int(dv) == 98 - int(sequencial + resto + "00") % 97


# --------------------------------------------------------------------------
# Valores monetários
# --------------------------------------------------------------------------
def parse_valor(valor: object) -> tuple[Decimal, str]:
    """Converte para ``Decimal`` com 2 casas. Devolve ``(valor, formato)``.

    ``formato`` é "numero" (já era número), "texto_ptbr" ("2.500,50") ou
    "texto" (texto com ponto decimal, como diz a documentação).

    Não arredonda: mais de 2 casas significativas é erro. Texto só com pontos
    e grupos de 3 dígitos ("2.500") é ambíguo (2500 ou 2,5?) e é recusado.
    """
    if valor is None:
        raise DadoInvalido("valor ausente (null)")
    if isinstance(valor, bool):
        raise DadoInvalido(f"valor booleano: {valor!r}")

    formato = "numero"
    if isinstance(valor, Decimal):
        numero = valor
    elif isinstance(valor, int):
        numero = Decimal(valor)
    elif isinstance(valor, float):
        numero = Decimal(str(valor))
    elif isinstance(valor, str):
        numero, formato = _parse_valor_texto(valor)
    else:
        raise DadoInvalido(f"tipo de valor não suportado: {type(valor).__name__}")

    if not numero.is_finite():
        raise DadoInvalido(f"valor não finito: {valor!r}")
    arredondado = numero.quantize(CENTAVOS)
    if arredondado != numero:
        raise DadoInvalido(f"valor com mais de 2 casas decimais: {valor!r}")
    return arredondado, formato


def _parse_valor_texto(bruto: str) -> tuple[Decimal, str]:
    s = re.sub(r"\s|R\$", "", bruto)
    if not s:
        raise DadoInvalido("valor vazio")
    if not re.fullmatch(r"-?[0-9.,]+", s):
        raise DadoInvalido(f"valor com caracteres inesperados: {bruto!r}")

    if "," in s and "." in s:
        # o último separador é o decimal; o outro é separador de milhar
        decimal_sep = "," if s.rfind(",") > s.rfind(".") else "."
        milhar_sep = "." if decimal_sep == "," else ","
        s = s.replace(milhar_sep, "")
        s = s.replace(decimal_sep, ".")
        formato = "texto_ptbr" if decimal_sep == "," else "texto"
    elif "," in s:
        if s.count(",") > 1:
            raise DadoInvalido(f"valor com mais de uma vírgula: {bruto!r}")
        s = s.replace(",", ".")
        formato = "texto_ptbr"
    elif "." in s:
        if re.fullmatch(r"-?\d{1,3}(\.\d{3})+", s):
            raise DadoAmbiguo(
                f"valor ambíguo (milhar ou decimal?): {bruto!r}"
            )
        if s.count(".") > 1:
            raise DadoInvalido(f"valor com mais de um ponto decimal: {bruto!r}")
        formato = "texto"
    else:
        formato = "texto"

    try:
        return Decimal(s), formato
    except InvalidOperation as exc:
        raise DadoInvalido(f"valor inválido: {bruto!r}") from exc


# --------------------------------------------------------------------------
# Datas
# --------------------------------------------------------------------------
_RE_ISO_DATA = re.compile(r"\d{4}-\d{2}-\d{2}")
_RE_BR_DATA = re.compile(r"(\d{2})/(\d{2})/(\d{4})")


def parse_data_local(valor: object) -> tuple[date, str]:
    """Converte para a data de calendário em Brasília. Devolve ``(data, formato)``.

    Aceita "AAAA-MM-DD", "DD/MM/AAAA" e data-hora ISO 8601. Data-hora com
    fuso (offset ou "Z") é convertida para America/Sao_Paulo ANTES de pegar
    a data: "2025-04-03T01:00:00Z" é 2 de abril às 22h em Brasília.
    Data-hora sem fuso é tratada como já estando em Brasília.
    """
    if not isinstance(valor, str) or not valor.strip():
        raise DadoInvalido(f"data ausente ou inválida: {valor!r}")
    s = valor.strip()
    try:
        if _RE_ISO_DATA.fullmatch(s):
            return date.fromisoformat(s), "iso"
        m = _RE_BR_DATA.fullmatch(s)
        if m:
            dia, mes, ano = (int(g) for g in m.groups())
            return date(ano, mes, dia), "dd/mm/aaaa"
        # fromisoformat só aceita "Z" a partir do Python 3.11
        dt = datetime.fromisoformat(s[:-1] + "+00:00" if s.endswith("Z") else s)
    except ValueError as exc:
        raise DadoInvalido(f"data inválida: {valor!r}") from exc
    if dt.tzinfo is None:
        return dt.date(), "datetime_sem_fuso"
    return dt.astimezone(FUSO).date(), "datetime"


def parse_datahora(valor: object) -> datetime:
    """Data-hora ISO 8601 com fuso, em Brasília. Sem fuso => assume Brasília."""
    if not isinstance(valor, str) or not valor.strip():
        raise DadoInvalido(f"data-hora ausente ou inválida: {valor!r}")
    s = valor.strip()
    try:
        dt = datetime.fromisoformat(s[:-1] + "+00:00" if s.endswith("Z") else s)
    except ValueError as exc:
        raise DadoInvalido(f"data-hora inválida: {valor!r}") from exc
    if dt.tzinfo is None:
        return dt.replace(tzinfo=FUSO)
    return dt.astimezone(FUSO)


# --------------------------------------------------------------------------
# Nomes (ente devedor)
# --------------------------------------------------------------------------
def chave_ente(nome: str) -> str:
    """Chave de comparação: sem acento, minúscula, espaços colapsados.

    "MUNICIPIO DE SAO PAULO" e "Município de São Paulo" têm a mesma chave.
    É só para COMPARAR; o nome exibido continua sendo o do tribunal.
    """
    sem_acento = unicodedata.normalize("NFKD", nome)
    sem_acento = "".join(c for c in sem_acento if not unicodedata.combining(c))
    return re.sub(r"\s+", " ", sem_acento).strip().casefold()


def limpar_espacos(nome: str) -> str:
    return re.sub(r"\s+", " ", nome).strip()
