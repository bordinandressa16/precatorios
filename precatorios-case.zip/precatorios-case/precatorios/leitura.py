"""Leitura dos arquivos como vieram. Tudo é aberto em modo binário/somente leitura."""
from __future__ import annotations

import csv
import hashlib
import io
import json
from decimal import Decimal
from pathlib import Path


def sha256(caminho: Path) -> str:
    return hashlib.sha256(caminho.read_bytes()).hexdigest()


def decodificar(dados: bytes) -> tuple[str, str]:
    """Tenta UTF-8 (o que a documentação promete) e cai para Windows-1252/Latin-1.

    Devolve ``(texto, codificacao_usada)``.
    """
    for codificacao in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            return dados.decode(codificacao), codificacao
        except UnicodeDecodeError:
            continue
    raise AssertionError("latin-1 decodifica qualquer byte")  # pragma: no cover


def ler_csv(caminho: Path) -> tuple[list[dict[str, str]], dict[str, str]]:
    """Lê um CSV detectando codificação e delimitador (vírgula ou ponto e vírgula).

    Devolve ``(linhas, meta)``. Cada linha traz a chave extra ``_linha`` com o
    número da linha no arquivo (cabeçalho = 1), para citar nas evidências.
    """
    texto, codificacao = decodificar(caminho.read_bytes())
    cabecalho = texto.splitlines()[0] if texto.strip() else ""
    delimitador = ";" if cabecalho.count(";") > cabecalho.count(",") else ","
    leitor = csv.DictReader(io.StringIO(texto, newline=""), delimiter=delimitador)
    linhas = []
    for registro in leitor:
        registro = {(k or "").strip(): (v or "").strip() for k, v in registro.items()}
        registro["_linha"] = str(leitor.line_num)
        linhas.append(registro)
    meta = {"codificacao": codificacao, "delimitador": delimitador}
    return linhas, meta


def ler_json(caminho: Path) -> list[dict]:
    """Lê uma lista JSON mantendo números como ``Decimal`` (sem erro de ponto flutuante).

    Cada item ganha ``_posicao`` (1 = primeiro objeto do array).
    """
    texto, _ = decodificar(caminho.read_bytes())
    dados = json.loads(texto, parse_float=Decimal)
    if not isinstance(dados, list):
        raise ValueError(f"{caminho.name}: esperava uma lista JSON na raiz")
    saida = []
    for posicao, item in enumerate(dados, start=1):
        if not isinstance(item, dict):
            raise ValueError(f"{caminho.name}: item {posicao} não é um objeto")
        saida.append({**item, "_posicao": posicao})
    return saida
