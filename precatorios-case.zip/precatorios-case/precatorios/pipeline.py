"""Orquestra leitura, consolidação, conferência de totais e escrita das saídas."""
from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from decimal import Decimal
from pathlib import Path

from .leitura import ler_csv, ler_json, sha256
from .normalizacao import formatar_processo
from .pagamentos import consolidar_pagamentos, total_pago_por_processo
from .precatorios import consolidar_precatorios
from .relatorio import ALERTA, DUVIDA, Relatorio

ARQUIVOS = ("tribunal.csv", "hub.csv", "apresentacoes.json", "pagamentos.json")


@dataclass
class Resultado:
    precatorios: list[dict]
    pagamentos: list[dict]
    relatorio: Relatorio
    hashes: dict[str, str]
    meta_tribunal: dict[str, str]


def processar(entrada: Path) -> Resultado:
    """Lê os 4 arquivos de ``entrada`` (somente leitura) e devolve a base limpa."""
    antes = {nome: sha256(entrada / nome) for nome in ARQUIVOS}
    rel = Relatorio()

    tribunal, meta = ler_csv(entrada / "tribunal.csv")
    hub, _ = ler_csv(entrada / "hub.csv")
    apresentacoes = ler_json(entrada / "apresentacoes.json")
    brutos = ler_json(entrada / "pagamentos.json")

    precatorios = consolidar_precatorios(tribunal, meta, apresentacoes, hub, rel)
    por_processo = {p["processo"]: p for p in precatorios}
    pagamentos = consolidar_pagamentos(brutos, por_processo, rel)

    totais = total_pago_por_processo(pagamentos)
    for p in precatorios:
        p["total_pago"] = totais.get(p["processo"], Decimal("0.00"))
        if p["total_pago"] < 0:
            rel.registrar(
                ALERTA, "base limpa", p["processo_formatado"],
                f"total pago negativo ({p['total_pago']}): estorno sem pagamento correspondente",
            )
        if p["total_pago"] > p["valor_face"]:
            rel.registrar(
                ALERTA, "base limpa", p["processo_formatado"],
                f"total pago ({p['total_pago']}) maior que o valor de face ({p['valor_face']}); "
                "pode ser correção monetária ou erro",
            )

    depois = {nome: sha256(entrada / nome) for nome in ARQUIVOS}
    if antes != depois:  # pragma: no cover - defesa
        raise RuntimeError("um arquivo de entrada mudou durante a execução")
    return Resultado(precatorios, pagamentos, rel, antes, meta)


def _fmt(v) -> str:
    return "" if v is None else str(v)


def _escrever_csv(caminho: Path, campos: list[str], linhas: list[dict]) -> None:
    with caminho.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=campos, lineterminator="\n")
        w.writeheader()
        for linha in linhas:
            w.writerow({c: _fmt(linha.get(c)) for c in campos})


def escrever_saidas(res: Resultado, saida: Path) -> None:
    saida.mkdir(parents=True, exist_ok=True)
    _escrever_csv(
        saida / "precatorios_limpo.csv",
        ["processo", "processo_formatado", "ente_devedor", "valor_face", "apresentado_em",
         "prazo_pagamento", "total_pago", "observacoes"],
        res.precatorios,
    )
    _escrever_csv(
        saida / "pagamentos_limpo.csv",
        ["evento_id", "processo", "tipo", "valor", "pago_em", "atualizado_em", "observacoes"],
        res.pagamentos,
    )
    quarentena = [
        {"origem": o.origem, "chave": o.chave, "motivo": o.motivo, "dado_original": o.detalhe}
        for o in res.relatorio.por_categoria(DUVIDA)
    ]
    _escrever_csv(
        saida / "quarentena.csv", ["origem", "chave", "motivo", "dado_original"], quarentena
    )
    (saida / "relatorio.md").write_text(gerar_relatorio_md(res), encoding="utf-8")


def _tabela(ocorrencias) -> list[str]:
    if not ocorrencias:
        return ["_Nenhum registro._", ""]
    linhas = ["| Origem | Chave | O que aconteceu |", "|---|---|---|"]
    for o in ocorrencias:
        texto = o.motivo + (f" — {o.detalhe}" if o.detalhe and o.categoria != DUVIDA else "")
        linhas.append(f"| {o.origem} | {o.chave} | {texto.replace('|', '/')} |")
    return linhas + [""]


def gerar_relatorio_md(res: Resultado) -> str:
    rel = res.relatorio
    c = rel.contagem()
    linhas = [
        "# Relatório da limpeza",
        "",
        "Gerado por `python -m precatorios`. Os arquivos de entrada não foram alterados "
        "(SHA-256 conferido antes e depois).",
        "",
        "## Entradas",
        "",
        "| Arquivo | SHA-256 |",
        "|---|---|",
        *[f"| {n} | `{h[:16]}…` |" for n, h in res.hashes.items()],
        "",
        f"`tribunal.csv` foi lido como **{res.meta_tribunal['codificacao']}**, delimitador "
        f"**{res.meta_tribunal['delimitador']!r}**.",
        "",
        "## Resultado",
        "",
        f"- Precatórios na base limpa: **{len(res.precatorios)}**",
        f"- Eventos de pagamento na base limpa: **{len(res.pagamentos)}**",
        f"- Corrigidos: {c['corrigido']} · Descartados: {c['descartado']} · "
        f"Em dúvida (fora da base): {c['duvida']} · Em dúvida (na base, com alerta): {c['alerta']}",
        "",
        "### Total pago por processo (pagamentos − estornos)",
        "",
        "| Processo | Ente | Valor de face | Total pago | Prazo |",
        "|---|---|---:|---:|---|",
        *[
            f"| {p['processo_formatado']} | {p['ente_devedor']} | {p['valor_face']} | "
            f"{p['total_pago']} | {_fmt(p['prazo_pagamento'])} |"
            for p in res.precatorios
        ],
        "",
        "## Corrigidos",
        "",
        "Entraram na base, mas foram normalizados ou recalculados.",
        "",
        *_tabela(rel.por_categoria("corrigido")),
        "## Descartados",
        "",
        "Só cópias redundantes: nenhuma informação se perde.",
        "",
        *_tabela(rel.por_categoria("descartado")),
        "## Em dúvida — fora da base (quarentena)",
        "",
        "Podem ser dinheiro ou precatórios reais, mas faltam dados ou há conflito. "
        "Não entram em nenhum total até alguém decidir. Detalhes em `quarentena.csv`.",
        "",
        *_tabela(rel.por_categoria("duvida")),
        "## Em dúvida — na base, com alerta",
        "",
        "Entraram na base, mas precisam de confirmação.",
        "",
        *_tabela(rel.por_categoria("alerta")),
    ]
    return "\n".join(linhas)
