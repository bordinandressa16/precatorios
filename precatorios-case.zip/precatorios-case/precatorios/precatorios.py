"""Consolidação dos precatórios: tribunal.csv é a fonte; hub.csv só é comparado.

* ``tribunal.csv``     -> ente e valor de face (fonte de verdade, por ser o devedor/tribunal)
* ``apresentacoes.json``-> data de apresentação (base do prazo)
* ``hub.csv``          -> exportação do sistema; usada para achar divergências
"""
from __future__ import annotations

from datetime import date
from decimal import Decimal

from .normalizacao import (
    DadoInvalido,
    chave_ente,
    formatar_processo,
    limpar_espacos,
    normalizar_processo,
    parse_data_local,
    parse_valor,
)
from .prazo import calcular_prazo
from .relatorio import ALERTA, CORRIGIDO, DESCARTADO, DUVIDA, Relatorio


def _processo_ou_duvida(bruto, origem, rel) -> str | None:
    try:
        return normalizar_processo(bruto)
    except DadoInvalido as exc:
        rel.registrar(DUVIDA, origem, str(bruto), str(exc))
        return None


def _ler_tribunal(linhas, meta, rel) -> dict[str, dict]:
    if meta["codificacao"] != "utf-8-sig" or meta["delimitador"] != ",":
        rel.registrar(
            CORRIGIDO, "tribunal.csv", "(arquivo)",
            f"formato diferente do documentado (v2.1: UTF-8, vírgula): lido como "
            f"{meta['codificacao']}, delimitador {meta['delimitador']!r}, valores em pt-BR",
        )
    achados: dict[str, dict] = {}
    for linha in linhas:
        origem = f"tribunal.csv linha {linha['_linha']}"
        processo = _processo_ou_duvida(linha.get("numero_processo"), origem, rel)
        if processo is None:
            continue
        try:
            face, _ = parse_valor(linha.get("valor_face"))
            if face <= 0:
                raise DadoInvalido(f"valor_face não positivo: {face}")
            ente = limpar_espacos(linha.get("ente_devedor", ""))
            if not ente:
                raise DadoInvalido("ente_devedor vazio")
        except DadoInvalido as exc:
            rel.registrar(DUVIDA, origem, formatar_processo(processo), str(exc))
            continue
        novo = {"ente": ente, "valor_face": face, "origem": origem}
        if processo in achados:
            antigo = achados[processo]
            if (antigo["ente"], antigo["valor_face"]) == (ente, face):
                rel.registrar(DESCARTADO, origem, processo, "linha duplicada idêntica")
            else:
                rel.registrar(
                    DUVIDA, origem, formatar_processo(processo),
                    f"processo repetido com dados diferentes de {antigo['origem']}",
                )
                achados[processo]["conflito"] = True
            continue
        achados[processo] = novo
    return {p: d for p, d in achados.items() if not d.get("conflito")}


def _ler_apresentacoes(brutos, rel) -> dict[str, date]:
    saida: dict[str, date] = {}
    for reg in brutos:
        origem = f"apresentacoes.json #{reg['_posicao']}"
        processo = _processo_ou_duvida(reg.get("processo"), origem, rel)
        if processo is None:
            continue
        try:
            data, formato = parse_data_local(reg.get("apresentado_em"))
        except DadoInvalido as exc:
            rel.registrar(DUVIDA, origem, formatar_processo(processo), str(exc))
            continue
        if formato in ("datetime", "datetime_sem_fuso"):
            rel.registrar(
                CORRIGIDO, origem, formatar_processo(processo),
                f"apresentado_em {reg['apresentado_em']!r} é data-hora; usada a data de "
                f"Brasília ({data}) para aplicar a regra do dia 2 de abril",
            )
        saida[processo] = data
    return saida


def consolidar_precatorios(
    tribunal_linhas, tribunal_meta, apresentacoes, hub_linhas, rel: Relatorio
) -> list[dict]:
    """Devolve a lista de precatórios da base limpa (sem totais pagos ainda)."""
    tribunal = _ler_tribunal(tribunal_linhas, tribunal_meta, rel)
    apres = _ler_apresentacoes(apresentacoes, rel)

    hub: dict[str, dict] = {}
    for linha in hub_linhas:
        origem = f"hub.csv linha {linha['_linha']}"
        processo = _processo_ou_duvida(linha.get("processo"), origem, rel)
        if processo is None:
            continue
        hub[processo] = {**linha, "origem": origem}

    base: list[dict] = []
    for processo, t in sorted(tribunal.items()):
        fmt = formatar_processo(processo)
        obs: list[str] = []
        apresentado = apres.get(processo)
        h = hub.get(processo)

        if apresentado is None and h is not None:
            try:
                apresentado, _ = parse_data_local(h.get("apresentado_em"))
                obs.append("data de apresentação veio só do hub.csv")
                rel.registrar(
                    ALERTA, t["origem"], fmt,
                    "sem registro em apresentacoes.json; data de apresentação tirada do hub.csv",
                )
            except DadoInvalido:
                apresentado = None
        if apresentado is None:
            rel.registrar(
                ALERTA, t["origem"], fmt,
                "sem data de apresentação: prazo não pôde ser calculado",
            )
            obs.append("sem data de apresentação")

        prazo = calcular_prazo(apresentado) if apresentado else None

        if h is None:
            rel.registrar(
                ALERTA, t["origem"], fmt,
                "precatório do tribunal ausente em hub.csv (exportação incompleta?)",
            )
            obs.append("ausente do hub.csv")
        else:
            _comparar_com_hub(processo, fmt, t, h, apresentado, prazo, rel, obs)

        base.append({
            "processo": processo,
            "processo_formatado": fmt,
            "ente_devedor": t["ente"],
            "valor_face": t["valor_face"],
            "apresentado_em": apresentado,
            "prazo_pagamento": prazo,
            "observacoes": " | ".join(obs),
        })

    # Processos que aparecem em outras fontes mas não no tribunal.csv
    for processo, h in sorted(hub.items()):
        if processo in tribunal:
            continue
        previsto = ""
        try:
            data, _ = parse_data_local(h.get("apresentado_em"))
            previsto = f" Pela regra, o prazo seria {calcular_prazo(data)} (hub diz {h.get('prazo_pagamento')})."
        except DadoInvalido:
            pass
        rel.registrar(
            DUVIDA, h["origem"], formatar_processo(processo),
            "processo existe no hub.csv e em apresentacoes.json mas não no tribunal.csv: "
            "não entrou na base (tribunal incompleto ou hub com processo indevido?)." + previsto,
            f"ente={h.get('ente')!r} valor_face={h.get('valor_face')}",
        )
    for processo in sorted(set(apres) - set(tribunal) - set(hub)):
        rel.registrar(
            DUVIDA, "apresentacoes.json", formatar_processo(processo),
            "processo só existe em apresentacoes.json",
        )
    return base


def _comparar_com_hub(processo, fmt, t, h, apresentado, prazo, rel, obs):
    origem = h["origem"]
    if h.get("processo", "").strip() != fmt:
        rel.registrar(
            CORRIGIDO, origem, fmt,
            f"número do processo no hub.csv sem máscara CNJ ({h.get('processo')!r}): "
            "comparar o texto 'exatamente como está' não casaria com o tribunal",
        )

    ente_hub = h.get("ente", "")
    if chave_ente(ente_hub) != chave_ente(t["ente"]):
        rel.registrar(
            ALERTA, origem, fmt,
            f"ente divergente: tribunal diz {t['ente']!r}, hub diz {ente_hub!r}. "
            "Mantido o nome do tribunal.",
        )
        obs.append(f"ente diverge do hub ({ente_hub})")
    elif ente_hub != t["ente"]:
        rel.registrar(
            CORRIGIDO, origem, fmt,
            f"mesmo ente escrito de outra forma no hub ({ente_hub!r} x {t['ente']!r}); "
            "uma comparação textual exata acusaria divergência que não existe",
        )

    try:
        face_hub, _ = parse_valor(h.get("valor_face"))
        if face_hub != t["valor_face"]:
            rel.registrar(
                ALERTA, origem, fmt,
                f"valor de face divergente: tribunal {t['valor_face']}, hub {face_hub}. "
                "Mantido o valor do tribunal.",
            )
            obs.append(f"valor_face diverge do hub ({face_hub})")
    except DadoInvalido as exc:
        rel.registrar(ALERTA, origem, fmt, f"valor_face do hub ilegível: {exc}")

    if prazo is not None:
        try:
            prazo_hub = date.fromisoformat(h.get("prazo_pagamento", ""))
        except ValueError:
            prazo_hub = None
        if prazo_hub != prazo:
            rel.registrar(
                CORRIGIDO, origem, fmt,
                f"prazo do hub ({h.get('prazo_pagamento')}) diverge do calculado pela regra "
                f"({prazo}) para apresentação em {apresentado} (hub: "
                f"{h.get('apresentado_em')!r})",
            )
            obs.append(f"prazo do hub ({h.get('prazo_pagamento')}) estava errado")
