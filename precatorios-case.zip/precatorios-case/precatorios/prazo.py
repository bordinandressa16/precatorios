"""Regra constitucional do prazo de pagamento do precatório."""
from __future__ import annotations

from datetime import date

# Apresentado ATÉ 2 de abril (inclusive) => paga até 31/12 do ano seguinte.
# Depois disso => 31/12 do ano subsequente ao seguinte.
LIMITE_MES_DIA = (4, 2)


def calcular_prazo(apresentado_em: date) -> date:
    """Prazo de pagamento a partir da data de apresentação (data em Brasília).

    Quem chama é responsável por passar a data de calendário local, não a data
    em UTC: veja ``normalizacao.parse_data_local``.
    """
    ate_o_limite = (apresentado_em.month, apresentado_em.day) <= LIMITE_MES_DIA
    return date(apresentado_em.year + (1 if ate_o_limite else 2), 12, 31)
