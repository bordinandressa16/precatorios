"""Uso: python -m precatorios [--entrada case/dados] [--saida saida]"""
from __future__ import annotations

import argparse
from pathlib import Path

from .pipeline import escrever_saidas, processar


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Limpeza e reconciliação de precatórios")
    ap.add_argument("--entrada", type=Path, default=Path("case/dados"),
                    help="pasta com tribunal.csv, hub.csv, apresentacoes.json, pagamentos.json")
    ap.add_argument("--saida", type=Path, default=Path("saida"), help="pasta de saída")
    args = ap.parse_args(argv)

    if args.saida.resolve() == args.entrada.resolve():
        ap.error("a pasta de saída não pode ser a de entrada (os originais não são alterados)")

    res = processar(args.entrada)
    escrever_saidas(res, args.saida)

    c = res.relatorio.contagem()
    print(f"Precatórios na base: {len(res.precatorios)}")
    print(f"Pagamentos na base:  {len(res.pagamentos)}")
    print(f"Corrigidos: {c['corrigido']} | Descartados: {c['descartado']} | "
          f"Quarentena: {c['duvida']} | Alertas: {c['alerta']}")
    print(f"Saídas em {args.saida}/ (veja relatorio.md)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
