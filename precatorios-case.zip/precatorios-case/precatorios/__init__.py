"""Limpeza e reconciliação de precatórios (case técnico)."""
