"""Consolidação dos eventos de pagamento.

Princípios:
* O ``evento_id`` é a chave. Reenvios do mesmo evento não se somam: vale a
  versão com ``atualizado_em`` mais recente (idempotência).
* Nada que possa ser dinheiro de verdade é descartado. Só cópias redundantes
  são descartadas; o resto que não pode entrar vai para dúvida, com o motivo.
* Estorno subtrai do total pago; pagamento soma.
"""
from __future__ import annotations

import json
from collections import defaultdict
from decimal import Decimal

from .normalizacao import (
    DadoInvalido,
    formatar_processo,
    normalizar_processo,
    parse_data_local,
    parse_datahora,
    parse_valor,
)
from .relatorio import ALERTA, CORRIGIDO, DESCARTADO, DUVIDA, Relatorio

TIPOS = {"pagamento", "estorno"}
ARQUIVO = "pagamentos.json"


def _origem(reg: dict) -> str:
    return f"{ARQUIVO} #{reg['_posicao']}"


def _conteudo(reg: dict) -> dict:
    return {k: v for k, v in reg.items() if k != "_posicao"}


def _json(reg: dict) -> str:
    return json.dumps(_conteudo(reg), ensure_ascii=False, default=str)


def escolher_versoes(brutos: list[dict], rel: Relatorio) -> dict[str, dict]:
    """Uma versão por ``evento_id``: a de ``atualizado_em`` mais recente.

    Devolve ``{evento_id: registro_bruto}``. Cópias idênticas e versões
    antigas viram ``DESCARTADO``; empate ambíguo ou ``evento_id`` ausente
    vira ``DUVIDA`` e o evento sai da base.
    """
    grupos: dict[str, list[dict]] = defaultdict(list)
    for reg in brutos:
        eid = reg.get("evento_id")
        if not isinstance(eid, str) or not eid.strip():
            rel.registrar(
                DUVIDA, _origem(reg), "(sem evento_id)",
                "evento sem evento_id: não dá para deduplicar nem reimportar com segurança",
                _json(reg),
            )
            continue
        grupos[eid.strip()].append(reg)

    escolhidos: dict[str, dict] = {}
    for eid, regs in grupos.items():
        if len(regs) == 1:
            escolhidos[eid] = regs[0]
            continue

        distintos: list[dict] = []
        for reg in regs:
            if _conteudo(reg) not in [_conteudo(d) for d in distintos]:
                distintos.append(reg)

        if len(distintos) == 1:
            vencedor = distintos[0]
        else:
            try:
                ordenados = sorted(
                    distintos, key=lambda r: parse_datahora(r.get("atualizado_em")),
                    reverse=True,
                )
            except DadoInvalido as exc:
                for reg in regs:
                    rel.registrar(
                        DUVIDA, _origem(reg), eid,
                        f"versões diferentes do mesmo evento e atualizado_em ilegível ({exc})",
                        _json(reg),
                    )
                continue
            primeiro, segundo = ordenados[0], ordenados[1]
            if parse_datahora(primeiro["atualizado_em"]) == parse_datahora(segundo["atualizado_em"]):
                for reg in regs:
                    rel.registrar(
                        DUVIDA, _origem(reg), eid,
                        "versões diferentes do mesmo evento com o mesmo atualizado_em: "
                        "não há como saber qual vale",
                        _json(reg),
                    )
                continue
            vencedor = primeiro

        for reg in regs:
            if reg is vencedor:
                continue
            if _conteudo(reg) == _conteudo(vencedor):
                rel.registrar(
                    DESCARTADO, _origem(reg), eid,
                    f"cópia idêntica de {_origem(vencedor)} (reenvio do mesmo evento)",
                )
            else:
                rel.registrar(
                    DESCARTADO, _origem(reg), eid,
                    f"versão substituída por {_origem(vencedor)}, atualizada depois",
                    f"valor {reg.get('valor')} (atualizado_em {reg.get('atualizado_em')}) "
                    f"-> valor {vencedor.get('valor')} "
                    f"(atualizado_em {vencedor.get('atualizado_em')})",
                )
        escolhidos[eid] = vencedor
    return escolhidos


def validar_evento(
    eid: str, reg: dict, precatorios: dict[str, dict], rel: Relatorio,
    reenviado: bool = False,
) -> dict | None:
    """Valida e normaliza um evento. Devolve ``None`` se foi para dúvida."""
    origem = _origem(reg)
    motivos: list[str] = []
    correcoes: list[str] = []
    alertas: list[str] = []

    processo = pago_em = atualizado = valor = None

    try:
        processo = normalizar_processo(reg.get("processo"))
        if formatar_processo(processo) != reg["processo"].strip():
            correcoes.append(
                f"processo {reg['processo']!r} sem a máscara CNJ, normalizado para "
                f"{formatar_processo(processo)}"
            )
    except DadoInvalido as exc:
        motivos.append(str(exc))

    try:
        valor, formato = parse_valor(reg.get("valor"))
        if formato != "numero":
            correcoes.append(
                f"valor em texto {reg['valor']!r} (a documentação diz número) convertido "
                f"para {valor}"
            )
        if valor <= 0:
            motivos.append(f"valor não positivo ({valor}); o schema exige valor > 0")
    except DadoInvalido as exc:
        motivos.append(str(exc))

    tipo = reg.get("tipo")
    if tipo not in TIPOS:
        motivos.append(f"tipo desconhecido: {tipo!r}")
    elif tipo == "estorno":
        correcoes.append(
            "tipo 'estorno' (a documentação diz que é sempre 'pagamento'): subtrai do total"
        )

    try:
        pago_em, formato = parse_data_local(reg.get("data_pagamento"))
        if formato != "iso":
            correcoes.append(
                f"data {reg['data_pagamento']!r} ({formato}) convertida para {pago_em}"
            )
    except DadoInvalido as exc:
        motivos.append(str(exc))

    try:
        atualizado = parse_datahora(reg.get("atualizado_em"))
    except DadoInvalido as exc:
        motivos.append(str(exc))

    if pago_em and atualizado and pago_em > atualizado.date():
        motivos.append(
            f"data_pagamento {pago_em} é posterior a atualizado_em "
            f"{atualizado.date()}: provável troca de dia/mês ou erro de data"
        )

    if processo and processo not in precatorios:
        motivos.append(
            f"processo {formatar_processo(processo)} não consta em tribunal.csv: "
            "não existe precatório para vincular (o schema exige FK)"
        )

    if motivos:
        rel.registrar(DUVIDA, origem, eid, "; ".join(motivos), _json(reg))
        return None

    apresentado = precatorios[processo].get("apresentado_em")
    if apresentado and pago_em < apresentado:
        alertas.append(
            f"pagamento em {pago_em} é anterior à apresentação do precatório "
            f"({apresentado}); confirmar"
        )
    if reenviado:
        alertas.append("evento reenviado com conteúdo diferente; vale a versão mais recente")

    if correcoes:
        rel.registrar(CORRIGIDO, origem, eid, "; ".join(correcoes))
    if alertas:
        rel.registrar(ALERTA, origem, eid, "; ".join(alertas))

    return {
        "evento_id": eid,
        "processo": processo,
        "tipo": tipo,
        "valor": valor,
        "pago_em": pago_em,
        "atualizado_em": atualizado.isoformat(),
        "observacoes": " | ".join(correcoes + alertas),
    }


def consolidar_pagamentos(
    brutos: list[dict], precatorios: dict[str, dict], rel: Relatorio
) -> list[dict]:
    """Pipeline completo de pagamentos. Idempotente: mesma entrada, mesma saída."""
    contagem_eventos = defaultdict(set)
    for reg in brutos:
        if isinstance(reg.get("evento_id"), str):
            contagem_eventos[reg["evento_id"].strip()].add(
                json.dumps(_conteudo(reg), sort_keys=True, default=str)
            )

    eventos = []
    for eid, reg in escolher_versoes(brutos, rel).items():
        reenviado = len(contagem_eventos[eid]) > 1
        evento = validar_evento(eid, reg, precatorios, rel, reenviado)
        if evento:
            eventos.append(evento)
    return sorted(eventos, key=lambda e: (e["pago_em"], e["evento_id"]))


def total_pago_por_processo(eventos: list[dict]) -> dict[str, Decimal]:
    """Pagamentos somam, estornos subtraem."""
    totais: dict[str, Decimal] = defaultdict(lambda: Decimal("0.00"))
    for e in eventos:
        sinal = 1 if e["tipo"] == "pagamento" else -1
        totais[e["processo"]] += sinal * e["valor"]
    return dict(totais)
