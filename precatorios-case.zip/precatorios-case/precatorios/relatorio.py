"""Registro do que a limpeza fez, em três destinos possíveis para cada registro."""
from __future__ import annotations

from dataclasses import dataclass, field

CORRIGIDO = "corrigido"  # entrou na base, mas foi alterado/normalizado
DESCARTADO = "descartado"  # redundante: nenhuma informação se perde
DUVIDA = "duvida"  # precisa de decisão humana; fica FORA da base e dos totais
ALERTA = "alerta"  # entrou na base, mas alguém precisa confirmar


@dataclass
class Ocorrencia:
    categoria: str
    origem: str  # arquivo e posição, ex.: "pagamentos.json #4"
    chave: str  # evento_id ou processo
    motivo: str
    detalhe: str = ""


@dataclass
class Relatorio:
    ocorrencias: list[Ocorrencia] = field(default_factory=list)

    def registrar(self, categoria, origem, chave, motivo, detalhe=""):
        self.ocorrencias.append(Ocorrencia(categoria, origem, chave, motivo, detalhe))

    def por_categoria(self, categoria: str) -> list[Ocorrencia]:
        return [o for o in self.ocorrencias if o.categoria == categoria]

    def contagem(self) -> dict[str, int]:
        return {
            c: len(self.por_categoria(c))
            for c in (CORRIGIDO, DESCARTADO, DUVIDA, ALERTA)
        }
