# Diagnóstico — por que os números não batem com os do tribunal

Este documento responde aos itens 1 (diagnóstico), 3 (prevenção) e 4 (dúvidas) do enunciado. O item 2 (limpeza) é o programa em `precatorios/`; o resultado dele, rodado nos arquivos do case, está em `saida/` (veja `saida/relatorio.md`).

**Como li os arquivos:** abri os quatro arquivos de `case/dados/` em modo binário, conferi a codificação com `file`, li o JSON preservando decimais (sem `float`) e refiz à mão os totais e os prazos de cada processo. Citações de arquivo usam: `pagamentos.json #N` = N-ésimo objeto do array (base 1); `hub.csv linha N` e `tribunal.csv linha N` = linha do arquivo (cabeçalho = linha 1).

**Limites do que afirmo:** não recebi o script de importação nem o código que gera o `hub.csv`. Onde falo da causa dentro desses códigos, é hipótese baseada no comportamento observado, e está marcada como tal.

## Resumo

Os números não batem por dois motivos que se alimentam: **(a)** o processo soma eventos sem identificar repetições, correções e estornos, e **(b)** tudo que não consegue ler é descartado sem avisar. Por cima disso, a documentação do tribunal não descreve os arquivos reais, o que faz o leitor de cada arquivo falhar de formas diferentes.

| # | Problema | Gravidade | Relação |
|---|---|---|---|
| 1 | Importação soma cada evento, sem idempotência nem versão | Crítica | **Causa** dos totais inflados; só é possível porque o banco permite (9) |
| 2 | Evento ilegível é ignorado sem avisar ninguém | Crítica | **Causa** de "ninguém sabe onde nem por quê"; amplifica 1, 3, 5 |
| 3 | Estorno é somado como pagamento | Alta | Consequência de 1 + 6 (documentação diz que só há "pagamento") |
| 4 | Prazo de pagamento errado em 2 de 5 processos | Alta | Consequência de 6 (datas em formatos mistos) e da falta de teste |
| 5 | Processo sem máscara cria "outro" processo | Alta | Consequência de 6 e 9 |
| 6 | A documentação (v2.1) não descreve os arquivos reais | Alta | **Causa** de 2, 4, 5 |
| 7 | Conferência manual por texto exato, no Excel | Média | Consequência de 6; esconde divergências reais e inventa falsas |
| 8 | Divergências reais entre tribunal e hub | Média | Só aparecem depois de normalizar (7) |
| 9 | O banco não impede nenhum dos problemas acima | Média | **Causa** permissiva de 1, 3, 5 |
| 10 | Pagamento anterior à apresentação do precatório | Baixa | Possível erro de dado; evidência fraca |

---

## 1. Importação soma cada evento, sem idempotência nem versão — **crítica**

**O que acontece.** O passo 2 do fluxo diz que o script "soma cada valor ao total pago" e que, se falha no meio, o operador "roda de novo com o mesmo arquivo". Somar não é repetível: cada execução adiciona de novo o que já entrou.

**Evidência.**
- `pagamentos.json #2` e `#4` são o mesmo evento, idêntico (`ev-002`, R$ 2.500,50). Somado duas vezes.
- `pagamentos.json #1` e `#9` têm o mesmo `evento_id` (`ev-001`) e conteúdos diferentes: R$ 15.000,00 (`atualizado_em` 10/03 10h) e R$ 15.500,00 (`atualizado_em` 11/03 09h). É uma correção; somar produz R$ 30.500,00 onde o certo é R$ 15.500,00. A documentação diz que `evento_id` é "identificador único"; não é.
- O passo 1 diz que o tribunal manda **todo dia** os eventos dos **últimos 7 dias**. Se for assim, cada evento chega em até 7 arquivos seguidos. (Inferência pela descrição do processo; é coerente com as repetições do arquivo.)
- `schema.sql`: `pagamento.evento_id` é `TEXT NOT NULL` sem `UNIQUE`. O banco aceita a repetição.

**Impacto.** Total pago inflado. Simulação com soma simples (estorno como positivo, chave = texto do processo como veio): `0012345-10.2019.8.26.0053` aparece com **R$ 30.500,00 a R$ 35.501,00** (conforme o script leia ou não o texto "2.500,50") contra **R$ 18.000,50** corretos, ou seja, de 69% a 97% acima. É a diferença que a operação vê contra o tribunal.

**Relação.** Causa. Foi o que mais gerou número errado, e o item 2 impede que alguém note.

## 2. Evento que não pode ser importado é ignorado sem avisar — **crítica**

**O que acontece.** Passo 5: "o script ignora e segue. Ninguém é avisado." Sem rejeitados guardados, sem contagem, sem alerta.

**Evidência.** Três eventos de `pagamentos.json` não são importáveis e somem sem rastro:
- `#5` `ev-004`: `valor` nulo (processo 0023456…, 03/05/2025). O pagamento provavelmente existiu; o valor é desconhecido.
- `#11` `ev-009`: `valor` −200 com `tipo` "pagamento" (o schema exige `valor > 0`), em processo que não está no `tribunal.csv`.
- `#12` `ev-010`: `processo` vazio, R$ 750,00 em 01/08/2025. Dinheiro sem destino.

E, dependendo do script, o `#2` (`valor` em texto "2.500,50") também cai aqui.

**Impacto.** O total do sistema fica diferente do tribunal por motivos que ninguém consegue listar. A operação "acha que os números não batem, mas ninguém sabe dizer onde nem por quê" é exatamente este sintoma. Também não há como cobrar do tribunal um dado que ninguém sabe que faltou.

**Relação.** Causa do desconhecimento. Consequência do que o item 6 produz (arquivos fora do contrato) e amplifica 1, 3 e 5.

## 3. Estorno é somado como pagamento — **alta**

**Evidência.** `pagamentos.json #7` (`ev-006`, pagamento de R$ 5.000,00 em 20/02/2025) e `#8` (`ev-007`, `tipo: "estorno"`, R$ 5.000,00 em 21/02/2025), ambos do processo `0034567-32.2018.8.26.0405`. O valor do estorno é positivo; o tipo é que o diferencia. O `schema.sql` já aceita `tipo IN ('pagamento','estorno')`, mas a documentação diz "tipo: sempre 'pagamento'" e o fluxo "soma cada valor".

**Impacto.** O processo aparece com R$ 10.000,00 pagos; o real é R$ 0,00. É o pior tipo de erro: dá a impressão de dívida quitada pela metade quando nada está pago.

**Relação.** Consequência de 1 (soma cega) e 6 (documentação desatualizada).

## 4. Prazo de pagamento errado — **alta**

**Regra** (enunciado): apresentado **até** 2 de abril → 31/12 do ano seguinte; depois → 31/12 do ano subsequente ao seguinte.

**Evidência.** Recalculei os seis processos (data de Brasília, `America/Sao_Paulo`):

| Processo | Apresentação (como veio) | Data em Brasília | Prazo correto | `hub.csv` |
|---|---|---|---|---|
| 0012345-10.2019.8.26.0053 | `2025-04-02` | 02/04/2025 | **31/12/2026** | 31/12/**2027** ❌ (linha 2) |
| 0023456-21.2020.8.26.0053 | `2025-04-03` | 03/04/2025 | 31/12/2027 | 31/12/2027 ✔ (linha 3) |
| 0034567-32.2018.8.26.0405 | `2024-02-29` | 29/02/2024 | 31/12/2025 | 31/12/2025 ✔ (linha 4) |
| 0045678-43.2021.5.02.0011 | `2025-04-02T23:30:00-03:00` | 02/04/2025 | 31/12/2026 | 31/12/2026 ✔ (linha 5) |
| 0056789-54.2017.4.03.6100 | `2025-04-03T01:00:00Z` | **02/04/2025 22h** | **31/12/2026** | 31/12/**2027** ❌ (linha 6) |
| 0067890-65.2016.8.26.0053 | `2023-12-31` | 31/12/2023 | 31/12/2025 | (ausente do hub) |

Duas leituras do hub contradizem a si mesmas: as linhas 2 e 5 são do **mesmo dia** (2 de abril de 2025) e têm prazos diferentes. A linha 6 está certa só se o dia valer em UTC (3 de abril), mas o instante é 22h do dia 2 em Brasília.

**Hipóteses sobre a causa (não vi o código do hub):** o limite de 2 de abril tratado como exclusivo para datas sem hora (`<` em vez de `<=`) e uso da data em UTC para datas com `Z`. Os três formatos de data misturados em `apresentacoes.json` e `hub.csv` (data pura, data-hora com offset, data-hora UTC) são o que torna esses erros possíveis.

**Impacto.** Os dois processos com prazo errado foram apresentados no **último dia** do prazo mais curto, e aparecem com **um ano a mais** (31/12/2027 em vez de 31/12/2026). A equipe prioriza a carteira pelo prazo; esses processos (R$ 45.000,00 e R$ 22.000,00 de face, pelo `hub.csv`) ficariam atrás de outros durante um ano inteiro, com risco de prazo constitucional vencido sem ação.

**Relação.** Consequência do item 6 (formatos e fuso não documentados) e da ausência de testes nos casos de borda (2 e 3 de abril, 29/02, UTC).

**Premissa a confirmar:** que a data legal da apresentação é a de Brasília (veja Dúvidas, T7). Os testes cobrem os dois lados do limite e a conversão de fuso.

## 5. Número de processo sem máscara cria "outro" processo — **alta**

**Evidência.**
- `pagamentos.json #6` (`ev-005`, R$ 1.200,00): `processo` é `00234562120208260053`, enquanto `#3` (`ev-003`, R$ 8.000,00) usa `0023456-21.2020.8.26.0053`. Mesmo processo, escrito de dois jeitos.
- `hub.csv linha 3`: o mesmo processo sem máscara.
- `schema.sql`: `numero_processo CHAR(20)`, mas o formato CNJ com máscara tem **25** caracteres. Testei em PostgreSQL 16: inserir `0012345-10.2019.8.26.0053` falha com `value too long for type character(20)`. Ou seja, o banco só funciona se alguém tirar a máscara antes, e nenhum documento diz quem faz isso.

**Impacto.** Se a chave é o texto, os R$ 1.200,00 viram um processo sem precatório (ou ficam de fora do total do `0023456…`, que passa de R$ 9.200,00 para R$ 8.000,00). O operador, comparando "exatamente como está escrito", não acha a correspondência.

**Relação.** Consequência de 6 (a máscara não é padronizada) e 9 (o banco não diz qual é a forma canônica; `CHAR(20)` sugere dígitos, mas sem `CHECK`).

## 6. A documentação (v2.1) não descreve os arquivos reais — **alta**

| Documentado | O que o arquivo tem | Evidência |
|---|---|---|
| `tribunal.csv` em UTF-8 | ISO-8859-1 (`file`: "ISO-8859 text"); lido como UTF-8, "Município" vira `Munic�pio` | `tribunal.csv` inteiro |
| Campos separados por vírgula | Ponto e vírgula | linha 1 |
| Valor "com ponto como separador decimal" | `45.000,00` (ponto de milhar, vírgula decimal) | `tribunal.csv` linhas 2–6 |
| `valor` é número | `"2.500,50"` (texto, pt-BR) | `pagamentos.json #2` e `#4` |
| `data_pagamento` é `AAAA-MM-DD` | `"10/04/2025"` | `pagamentos.json #2` e `#4` |
| `tipo` é sempre "pagamento" | existe `"estorno"` | `pagamentos.json #8` |
| `evento_id` é único | `ev-001` e `ev-002` se repetem | `#1/#9`, `#2/#4` |
| "eventos dos últimos 7 dias" | datas de 20/02/2025 a 10/08/2025 | todo o arquivo |
| (não documentados) | `hub.csv` e `apresentacoes.json`, com datas em 3 formatos | — |

O `tribunal.csv` tem exatamente o perfil de um CSV salvo pelo Excel em português do Brasil (ponto e vírgula, Windows-1252, vírgula decimal, CRLF). Pelo passo 3 o operador "abre no Excel, confere, salva". É hipótese plausível de que o arquivo da documentação e o arquivo que chega diferem porque alguém o salva no meio do caminho; só o tribunal e a operação podem confirmar (T5).

**Impacto.** Cada leitor falha de um jeito: um lê `45.000,00` como texto, outro "2.500,50" como 2,50050. Sem contrato, a quebra é silenciosa (item 2).

**Relação.** Causa de 2, 4, 5.

## 7. Conferência manual por texto exato, no Excel — **média**

**Evidência.** Passo 3: o operador compara `tribunal.csv` com `hub.csv` "procurando o nome do ente e o número do processo exatamente como estão escritos".
- Falso positivo: `hub.csv linha 2` traz `MUNICIPIO DE SAO PAULO`; o tribunal escreve `Município de São Paulo`. É o mesmo ente.
- Falso positivo: `hub.csv linha 3` traz o processo sem máscara.
- Risco do Excel: um número de 20 dígitos sem máscara, aberto e salvo no Excel, vira número (perde zeros à esquerda e dígitos além do 15º). A linha 3 do hub já tem a forma que o Excel destruiria; é um risco, não algo que eu tenha observado acontecer.
- Falso negativo: as divergências **reais** (item 8) exigem comparar valor, ente e prazo, o que "procurar o texto" não faz.

**Impacto.** Tempo gasto com alarmes falsos e divergências reais passando. Além disso, o processo não é repetível nem auditável.

**Relação.** Consequência de 6. Esconde 8.

## 8. Divergências reais entre tribunal e hub — **média** (em dúvida)

Só aparecem depois de normalizar processo e ente:

| Processo | Tribunal | Hub | Observação |
|---|---|---|---|
| 0023456-21.2020.8.26.0053 | valor de face R$ 30.000,00 (`tribunal.csv linha 3`) | R$ 31.000,00 (`hub.csv linha 3`) | R$ 1.000,00 de diferença |
| 0045678-43.2021.5.02.0011 | ente **União** (linha 5) | ente **Município de Santos** (linha 5) | entes diferentes |
| 0056789-54.2017.4.03.6100 | não consta | consta (R$ 22.000,00) e em `apresentacoes.json`, com o pagamento `ev-009` | processo órfão |
| 0067890-65.2016.8.26.0053 | consta (R$ 7.000,00) | não consta | com o pagamento `ev-011` de R$ 4.000,00 |

**Decisão que tomei, para a operação revisar:** o `tribunal.csv` é a fonte de ente e valor de face (é o devedor/tribunal quem define). O que diverge entra na base com alerta, e o `0056789…` fica na quarentena porque o tribunal não o lista. Não tenho como saber qual lado está certo: perguntas T8 a T10.

## 9. O banco não impede nenhum dos problemas acima — **média**

| Lacuna em `schema.sql` | Consequência |
|---|---|
| `pagamento.evento_id` sem `UNIQUE` | aceita a repetição do item 1 |
| sem `atualizado_em`/versão | impossível aplicar a correção `ev-001` com segurança |
| `numero_processo CHAR(20)` sem `CHECK` de formato | depende de alguém lembrar de tirar a máscara |
| sem `apresentado_em` nem `prazo_pagamento` | o prazo é calculado fora, em código sem teste (item 4) |
| nenhuma coluna de "total pago", embora o passo 2 fale em "total pago do processo no sistema" | o acumulador está fora do schema que recebi (pergunta O1); acumulador é frágil de qualquer forma |
| `ente_devedor` texto livre | três grafias do mesmo ente |
| sem tabela de importação nem de rejeitados | nada fica para auditar (item 2) |

## 10. Pagamento anterior à apresentação — **baixa**

`pagamentos.json #1/#9` (`ev-001`): pago em 10/03/2025; o precatório `0012345…` foi apresentado em 02/04/2025. Pode ser dado errado ou pagamento prévio legítimo. Entrou na base com alerta, não foi excluído.

## Observações que *não* são problemas

- `0034567…` (29/02/2024): prazo 31/12/2025, correto. Ano bissexto não quebra a regra.
- `0023456…` e `0045678…` têm prazo correto no hub (o `0045678…` está certo, mas inconsistente com a linha 2).
- Os dígitos verificadores CNJ dos seis números **não conferem** (dados fictícios). A função existe e está testada, mas não usei o dígito como critério de descarte; com dados reais vale ligá-lo.

---

# Prevenção

## No processo

1. **Receber por canal estruturado e com contrato**: SFTP ou API, UTF-8, layout versionado (JSON Schema para `pagamentos.json`, esquema de colunas para CSV). Mudança de layout só com versão nova da documentação.
2. **Ninguém abre e salva o arquivo do tribunal no Excel.** A conferência passa a ser um relatório automático (o `precatorios` já gera um) que compara por chave normalizada: processo (20 dígitos), ente (sem acento/caixa), valor e prazo.
3. **Reconciliação diária** do total pago por processo contra o tribunal, com lista de diferenças, não um alarme genérico.
4. **Um responsável e um prazo** para a fila de quarentena (`pagamento_rejeitado`). Evento pendente não é descartado.
5. **Fonte de verdade definida por campo** (ver T10), registrada na documentação.

## No script de importação

- **Idempotente**: chave `evento_id`, `INSERT … ON CONFLICT DO UPDATE` só se `atualizado_em` for maior. Rodar duas vezes o mesmo arquivo, ou arquivos sobrepostos, não muda nada.
- **Uma transação por arquivo** e **hash do arquivo** (`importacao.sha256 UNIQUE`): falha no meio desfaz tudo; o mesmo arquivo não entra duas vezes.
- **Validação de contrato**: campo ausente/desconhecido, tipo inesperado ou arquivo vazio **falha o job**, em vez de ser ignorado.
- **Nunca ignorar em silêncio**: o que não entra vai para `pagamento_rejeitado` com o payload e o motivo; ao final, resumo (lidos, gravados, atualizados, duplicados, rejeitados) e alerta se houver rejeitado.
- **Normalizar na borda**: processo para 20 dígitos, `Decimal`, datas na data de Brasília, `tipo` com sinal (estorno subtrai).
- **Testes** para as regras arriscadas. As de `tests/` já cobrem as funções puras e podem ser reaproveitadas na importação.

## No banco

`sql/001_prevencao.sql` (transacional; **rodei em PostgreSQL 16** sobre o schema original com dados repetidos, e `sql/teste_001.sql` confere o comportamento):

| Mudança | O que previne |
|---|---|
| `UNIQUE (evento_id)` em `pagamento` + `atualizado_em`, com upsert por versão | itens 1 e 3 |
| `CHECK (numero_processo ~ '^[0-9]{20}$')` | item 5 |
| `apresentado_em DATE` + `prazo_pagamento` **coluna gerada** com a regra do dia 2 de abril | item 4 (uma única implementação) |
| tabela `ente_devedor` com `nome_normalizado UNIQUE` e `precatorio.ente_id` | item 7 (três grafias) |
| tabelas `importacao` (hash único) e `pagamento_rejeitado` | itens 1 e 2 |
| view `precatorio_total_pago` (pagamento soma, estorno subtrai) | itens 1 e 3 (não existe acumulador para somar de novo) |
| função `cnj_dv_valido` (não ligada como `CHECK` por causa dos dados fictícios) | typos no número do processo |

**Cuidado na migração:** o passo 4a salva as duplicatas existentes em `pagamento_duplicado_backup` e mantém a linha de maior `id`. Se houver duplicatas com valores diferentes, a decisão correta depende do tribunal (T1).

---

# Dúvidas antes de pôr em produção

## Ao tribunal

- **T1.** `evento_id` identifica o evento ou a versão do evento? Reenviar o mesmo `evento_id` com outro valor (`ev-001`: 15.000 → 15.500) é correção? Vale sempre o maior `atualizado_em`?
- **T2.** O arquivo diário cobre mesmo os últimos 7 dias, com sobreposição? Por que o arquivo recebido traz de fevereiro a agosto de 2025?
- **T3.** Qual é o formato oficial de **estorno**? Valor sempre positivo? Existe referência ao evento estornado? Há outros tipos?
- **T4.** O que são `ev-004` (valor nulo; qual o valor?), `ev-009` (−200 com tipo "pagamento": é um estorno?) e `ev-010` (sem processo; a qual processo pertencem os R$ 750,00?)
- **T5.** O layout real do `tribunal.csv` é Latin-1, `;` e vírgula decimal, ou a documentação v2.1 é a verdadeira e alguém altera o arquivo no caminho?
- **T6.** `valor` como texto pt-BR e `data_pagamento` como `DD/MM/AAAA` são padrão de alguma origem ou erro? Como distinguir 10/04 de 04/10 no futuro?
- **T7.** A data legal de apresentação é a de Brasília? A "data de apresentação" é protocolo, autuação ou recebimento? O dia 2 de abril vai até 23h59 em Brasília?
- **T8.** O `tribunal.csv` é a lista completa? Por que `0056789-54.2017.4.03.6100` não está nele? Precatórios pagos ou cancelados saem da lista?
- **T9.** `valor_face` é o valor original ou o atualizado? Por que `0023456…` é R$ 30.000,00 para o tribunal e R$ 31.000,00 para o hub?
- **T10.** O ente de `0045678…` é a União ou o Município de Santos? (O número, `…5.02…`, é da Justiça do Trabalho, TRT 2.)
- **T11.** Existe pagamento anterior à apresentação do precatório (`ev-001`)? É legítimo?

## À operação

- **O1.** Onde está o script de importação e o acumulador de "total pago"? Não há coluna ou tabela para ele no `schema.sql` que recebi.
- **O2.** Quem gera `hub.csv` e `apresentacoes.json`, e como? Posso ver o código do cálculo de prazo?
- **O3.** Em divergência, qual fonte vale, tribunal ou hub? Quem decide?
- **O4.** Algum relatório, repasse ou priorização já usou os prazos errados (`0012345…`, `0056789…`) ou os totais inflados? É preciso comunicar alguém?
- **O5.** Qual o volume real (precatórios e eventos por dia)? O comportamento da importação em lote muda com isso?
- **O6.** Há duplicatas já gravadas em `pagamento`? A migração pode apagá-las depois do backup?
- **O7.** Quem é o dono da fila de quarentena e em quanto tempo ela precisa ser resolvida?
- **O8.** A conciliação deve comparar com o `valor_face` ou com o valor atualizado monetariamente? (Hoje o total pago nunca é confrontado com o saldo devido.)
