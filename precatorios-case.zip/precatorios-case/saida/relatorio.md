# Relatório da limpeza

Gerado por `python -m precatorios`. Os arquivos de entrada não foram alterados (SHA-256 conferido antes e depois).

## Entradas

| Arquivo | SHA-256 |
|---|---|
| tribunal.csv | `0ce8aab43966f28b…` |
| hub.csv | `75fcf6e07dc05078…` |
| apresentacoes.json | `0da8be22859b58fa…` |
| pagamentos.json | `83e761b199bfea34…` |

`tribunal.csv` foi lido como **cp1252**, delimitador **';'**.

## Resultado

- Precatórios na base limpa: **5**
- Eventos de pagamento na base limpa: **8**
- Corrigidos: 9 · Descartados: 2 · Em dúvida (fora da base): 4 · Em dúvida (na base, com alerta): 4

### Total pago por processo (pagamentos − estornos)

| Processo | Ente | Valor de face | Total pago | Prazo |
|---|---|---:|---:|---|
| 0012345-10.2019.8.26.0053 | Município de São Paulo | 45000.00 | 18000.50 | 2026-12-31 |
| 0023456-21.2020.8.26.0053 | Município de São Paulo | 30000.00 | 9200.00 | 2027-12-31 |
| 0034567-32.2018.8.26.0405 | Estado de São Paulo | 12500.00 | 0.00 | 2025-12-31 |
| 0045678-43.2021.5.02.0011 | União | 9800.00 | 3000.00 | 2026-12-31 |
| 0067890-65.2016.8.26.0053 | Município de São Paulo | 7000.00 | 4000.00 | 2025-12-31 |

## Corrigidos

Entraram na base, mas foram normalizados ou recalculados.

| Origem | Chave | O que aconteceu |
|---|---|---|
| tribunal.csv | (arquivo) | formato diferente do documentado (v2.1: UTF-8, vírgula): lido como cp1252, delimitador ';', valores em pt-BR |
| apresentacoes.json #4 | 0045678-43.2021.5.02.0011 | apresentado_em '2025-04-02T23:30:00-03:00' é data-hora; usada a data de Brasília (2025-04-02) para aplicar a regra do dia 2 de abril |
| apresentacoes.json #5 | 0056789-54.2017.4.03.6100 | apresentado_em '2025-04-03T01:00:00Z' é data-hora; usada a data de Brasília (2025-04-02) para aplicar a regra do dia 2 de abril |
| hub.csv linha 2 | 0012345-10.2019.8.26.0053 | mesmo ente escrito de outra forma no hub ('MUNICIPIO DE SAO PAULO' x 'Município de São Paulo'); uma comparação textual exata acusaria divergência que não existe |
| hub.csv linha 2 | 0012345-10.2019.8.26.0053 | prazo do hub (2027-12-31) diverge do calculado pela regra (2026-12-31) para apresentação em 2025-04-02 (hub: '2025-04-02') |
| hub.csv linha 3 | 0023456-21.2020.8.26.0053 | número do processo no hub.csv sem máscara CNJ ('00234562120208260053'): comparar o texto 'exatamente como está' não casaria com o tribunal |
| pagamentos.json #2 | ev-002 | valor em texto '2.500,50' (a documentação diz número) convertido para 2500.50; data '10/04/2025' (dd/mm/aaaa) convertida para 2025-04-10 |
| pagamentos.json #6 | ev-005 | processo '00234562120208260053' sem a máscara CNJ, normalizado para 0023456-21.2020.8.26.0053 |
| pagamentos.json #8 | ev-007 | tipo 'estorno' (a documentação diz que é sempre 'pagamento'): subtrai do total |

## Descartados

Só cópias redundantes: nenhuma informação se perde.

| Origem | Chave | O que aconteceu |
|---|---|---|
| pagamentos.json #1 | ev-001 | versão substituída por pagamentos.json #9, atualizada depois — valor 15000.0 (atualizado_em 2025-03-10T10:00:00-03:00) -> valor 15500.0 (atualizado_em 2025-03-11T09:00:00-03:00) |
| pagamentos.json #4 | ev-002 | cópia idêntica de pagamentos.json #2 (reenvio do mesmo evento) |

## Em dúvida — fora da base (quarentena)

Podem ser dinheiro ou precatórios reais, mas faltam dados ou há conflito. Não entram em nenhum total até alguém decidir. Detalhes em `quarentena.csv`.

| Origem | Chave | O que aconteceu |
|---|---|---|
| hub.csv linha 6 | 0056789-54.2017.4.03.6100 | processo existe no hub.csv e em apresentacoes.json mas não no tribunal.csv: não entrou na base (tribunal incompleto ou hub com processo indevido?). Pela regra, o prazo seria 2026-12-31 (hub diz 2027-12-31). |
| pagamentos.json #5 | ev-004 | valor ausente (null) |
| pagamentos.json #11 | ev-009 | valor não positivo (-200.00); o schema exige valor > 0; processo 0056789-54.2017.4.03.6100 não consta em tribunal.csv: não existe precatório para vincular (o schema exige FK) |
| pagamentos.json #12 | ev-010 | número de processo vazio |

## Em dúvida — na base, com alerta

Entraram na base, mas precisam de confirmação.

| Origem | Chave | O que aconteceu |
|---|---|---|
| hub.csv linha 3 | 0023456-21.2020.8.26.0053 | valor de face divergente: tribunal 30000.00, hub 31000.00. Mantido o valor do tribunal. |
| hub.csv linha 5 | 0045678-43.2021.5.02.0011 | ente divergente: tribunal diz 'União', hub diz 'Município de Santos'. Mantido o nome do tribunal. |
| tribunal.csv linha 6 | 0067890-65.2016.8.26.0053 | precatório do tribunal ausente em hub.csv (exportação incompleta?) |
| pagamentos.json #9 | ev-001 | pagamento em 2025-03-10 é anterior à apresentação do precatório (2025-04-02); confirmar; evento reenviado com conteúdo diferente; vale a versão mais recente |
