# Case técnico — precatórios

Limpeza e reconciliação dos arquivos do tribunal, com diagnóstico, proposta de prevenção e dúvidas.

| O quê | Onde |
|---|---|
| Diagnóstico, prevenção e dúvidas | [`DIAGNOSTICO.md`](DIAGNOSTICO.md) |
| Programa de limpeza (Python ≥ 3.10, só biblioteca padrão) | [`precatorios/`](precatorios/) |
| Testes | [`tests/`](tests/) |
| Migração SQL de prevenção (PostgreSQL) e seu teste | [`sql/`](sql/) |
| Resultado de uma execução nos dados do case | [`saida/`](saida/) |
| Materiais originais, intocados | [`case/`](case/) |

## Como rodar

Na raiz do repositório:

```bash
python3 -m precatorios                      # lê case/dados, escreve em saida/
python3 -m precatorios --entrada OUTRA_PASTA --saida OUTRA_SAIDA
```

A entrada é só lida (modo binário; o programa confere o SHA-256 dos quatro arquivos antes e depois e recusa uma pasta de saída igual à de entrada). Saídas:

- `precatorios_limpo.csv`: ente, valor de face, data de apresentação, **prazo recalculado**, **total pago** (pagamentos − estornos).
- `pagamentos_limpo.csv`: um evento por `evento_id`, valores e datas normalizados.
- `quarentena.csv`: o que ficou **fora** da base, com o motivo e o dado original.
- `relatorio.md`: tudo que foi **corrigido**, **descartado** ou ficou **em dúvida**, e por quê.

Testes:

```bash
pip install pytest      # único requisito de desenvolvimento
python3 -m pytest
```

No Windows, o `zoneinfo` precisa do pacote `tzdata` (`pip install tzdata`).

SQL (precisa de um PostgreSQL 14+ descartável):

```bash
psql -d scratch -f case/schema.sql
psql -d scratch -v ON_ERROR_STOP=1 -f sql/001_prevencao.sql
psql -d scratch -v ON_ERROR_STOP=1 -f sql/teste_001.sql
```

## Regras principais da limpeza

- **Chave do processo:** os 20 dígitos, com ou sem máscara.
- **Pagamentos:** a chave é `evento_id`; cópias idênticas e versões antigas são descartadas (vale o maior `atualizado_em`); estorno subtrai.
- **Nada que pareça dinheiro é descartado.** Só cópias redundantes são. Valor nulo ou negativo, processo vazio ou sem precatório vão para a quarentena com o motivo.
- **Fonte:** o `tribunal.csv` define ente e valor de face. O `hub.csv` só é comparado; divergência vira alerta.
- **Prazo:** recalculado pela regra do dia 2 de abril, a partir da data de **Brasília** (um instante em UTC ou com offset é convertido antes de se pegar o dia).
- **Valores:** `Decimal`, nunca `float`. Texto só com ponto e grupos de 3 dígitos (`"2.500"`) é ambíguo e é recusado.

As premissas que dependem de resposta do tribunal ou da operação estão em `DIAGNOSTICO.md` (seção "Dúvidas").

## Uso de IA

Usei IA (Claude) como assistente durante todo o trabalho: para ler os arquivos, propor a estrutura do código, escrever o código, os testes, o SQL e o texto do diagnóstico.

Como conferi o que ela produziu:

- **Dados:** refiz à mão os totais pagos e os prazos de cada processo e os comparei com a saída (`tests/test_e2e.py` guarda esses números). As posições e linhas citadas no diagnóstico foram conferidas contra os arquivos.
- **Código:** escrevi testes para as regras mais arriscadas (limite de 2 de abril nos dois lados, 29/02, UTC × Brasília, `"2.500,50"`, reenvio, versão antiga, ordem das linhas, estorno, originais intactos). Um teste falhou por erro do próprio teste (a data de pagamento posterior ao `atualizado_em` foi corretamente rejeitada pela regra) e foi corrigido.
- **SQL:** rodei a migração num PostgreSQL 16 local, sobre o schema original com duplicatas, e conferi prazo gerado, unicidade, upsert por versão e a view (`sql/teste_001.sql`). Também confirmei no banco que o número de processo com máscara não cabe em `CHAR(20)`.
- **Hipóteses:** o que é inferência (por exemplo, a causa do erro de prazo no hub, que não tenho o código para ver) está marcado como hipótese no diagnóstico. Os dígitos verificadores CNJ não conferem em nenhum número do case (dados fictícios), então não usei esse critério.
