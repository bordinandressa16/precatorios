"""Roda o pipeline nos arquivos reais do case e confere os números à mão."""
import hashlib
import shutil
from datetime import date
from decimal import Decimal
from pathlib import Path

import pytest

from precatorios.__main__ import main
from precatorios.pipeline import ARQUIVOS, escrever_saidas, processar

DADOS = Path(__file__).resolve().parent.parent / "case" / "dados"


@pytest.fixture(scope="module")
def res():
    return processar(DADOS)


def por_processo(res):
    return {p["processo_formatado"]: p for p in res.precatorios}


def test_totais_pagos_conferidos_a_mao(res):
    t = {k: v["total_pago"] for k, v in por_processo(res).items()}
    assert t == {
        "0012345-10.2019.8.26.0053": Decimal("18000.50"),  # 15.500,00 (reenvio) + 2.500,50
        "0023456-21.2020.8.26.0053": Decimal("9200.00"),  # 8.000 + 1.200 (processo sem máscara)
        "0034567-32.2018.8.26.0405": Decimal("0.00"),  # 5.000 pago − 5.000 estornado
        "0045678-43.2021.5.02.0011": Decimal("3000.00"),
        "0067890-65.2016.8.26.0053": Decimal("4000.00"),
    }


def test_prazos_recalculados(res):
    p = por_processo(res)
    assert p["0012345-10.2019.8.26.0053"]["prazo_pagamento"] == date(2026, 12, 31)  # hub: 2027
    assert p["0023456-21.2020.8.26.0053"]["prazo_pagamento"] == date(2027, 12, 31)
    assert p["0034567-32.2018.8.26.0405"]["prazo_pagamento"] == date(2025, 12, 31)
    assert p["0045678-43.2021.5.02.0011"]["prazo_pagamento"] == date(2026, 12, 31)
    assert p["0067890-65.2016.8.26.0053"]["prazo_pagamento"] == date(2025, 12, 31)


def test_valores_do_tribunal_csv_lidos_em_ptbr_e_latin1(res):
    p = por_processo(res)
    assert p["0012345-10.2019.8.26.0053"]["valor_face"] == Decimal("45000.00")
    assert p["0045678-43.2021.5.02.0011"]["ente_devedor"] == "União"
    assert res.meta_tribunal["delimitador"] == ";"


def test_o_que_ficou_de_fora_tem_motivo(res):
    fora = {o.chave: o.motivo for o in res.relatorio.por_categoria("duvida")}
    assert {"ev-004", "ev-009", "ev-010", "0056789-54.2017.4.03.6100"} <= set(fora)
    assert all(m for m in fora.values())
    assert not {e["evento_id"] for e in res.pagamentos} & {"ev-004", "ev-009", "ev-010"}


def test_divergencias_com_o_hub_sao_sinalizadas_sem_falso_positivo(res):
    alertas = " ".join(o.motivo for o in res.relatorio.por_categoria("alerta"))
    assert "30000.00" in alertas and "31000.00" in alertas  # valor_face
    assert "União" in alertas and "Município de Santos" in alertas  # ente
    # "MUNICIPIO DE SAO PAULO" x "Município de São Paulo" NÃO é divergência de ente
    assert "'MUNICIPIO DE SAO PAULO'" not in alertas


def test_nenhum_pagamento_na_base_sem_precatorio(res):
    processos = {p["processo"] for p in res.precatorios}
    assert {e["processo"] for e in res.pagamentos} <= processos


def test_resultado_e_deterministico(res):
    outra = processar(DADOS)
    assert outra.precatorios == res.precatorios
    assert outra.pagamentos == res.pagamentos


# --------------------------------------------- originais nunca são alterados
def _hashes(pasta):
    return {n: hashlib.sha256((pasta / n).read_bytes()).hexdigest() for n in ARQUIVOS}


def test_arquivos_originais_nao_sao_alterados(tmp_path):
    antes = _hashes(DADOS)
    r = processar(DADOS)
    escrever_saidas(r, tmp_path / "saida")
    assert _hashes(DADOS) == antes
    assert r.hashes == antes


def test_funciona_com_pasta_somente_leitura(tmp_path):
    copia = tmp_path / "dados"
    shutil.copytree(DADOS, copia)
    for f in copia.iterdir():
        f.chmod(0o444)
    copia.chmod(0o555)
    try:
        processar(copia)  # não pode tentar escrever nada ali
    finally:
        copia.chmod(0o755)


def test_cli_recusa_saida_igual_a_entrada(tmp_path, capsys):
    with pytest.raises(SystemExit):
        main(["--entrada", str(DADOS), "--saida", str(DADOS)])


def test_cli_gera_arquivos(tmp_path):
    assert main(["--entrada", str(DADOS), "--saida", str(tmp_path / "s")]) == 0
    nomes = {p.name for p in (tmp_path / "s").iterdir()}
    assert nomes == {"precatorios_limpo.csv", "pagamentos_limpo.csv",
                     "quarentena.csv", "relatorio.md"}
