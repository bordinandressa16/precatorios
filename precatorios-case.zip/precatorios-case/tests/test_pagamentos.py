import random
from datetime import date
from decimal import Decimal

from precatorios.pagamentos import consolidar_pagamentos, total_pago_por_processo
from precatorios.relatorio import DESCARTADO, DUVIDA, Relatorio

P1 = "0012345-10.2019.8.26.0053"
P1_NUM = "00123451020198260053"
PRECATORIOS = {P1_NUM: {"apresentado_em": date(2025, 4, 2)}}


def ev(eid, valor=1000, tipo="pagamento", processo=P1, dia="2025-05-10", atualizado=None):
    return {
        "evento_id": eid, "processo": processo, "valor": valor,
        "data_pagamento": dia, "tipo": tipo,
        "atualizado_em": atualizado or f"{dia}T10:00:00-03:00",
    }


def rodar(eventos):
    # imita ler_json: cada item ganha sua posição no arquivo
    brutos = [{**e, "_posicao": i} for i, e in enumerate(eventos, start=1)]
    rel = Relatorio()
    base = consolidar_pagamentos(brutos, PRECATORIOS, rel)
    return base, rel


def total(base):
    return total_pago_por_processo(base).get(P1_NUM, Decimal("0.00"))


# ------------------------------------------------------------ idempotência
def test_reenvio_identico_nao_soma_duas_vezes():
    base, rel = rodar([ev("a", 1000), ev("a", 1000)])
    assert total(base) == Decimal("1000.00")
    assert len(rel.por_categoria(DESCARTADO)) == 1


def test_rodar_o_arquivo_inteiro_duas_vezes_da_o_mesmo_resultado():
    eventos = [ev("a", 1000), ev("b", 250, dia="2025-05-11"), ev("c", 100, "estorno", dia="2025-05-12")]
    uma, _ = rodar(eventos)
    duas, _ = rodar(eventos + eventos)
    assert uma == duas
    assert total(duas) == Decimal("1150.00")


def test_resultado_nao_depende_da_ordem_das_linhas():
    eventos = [
        ev("a", 1000), ev("a", 1200, atualizado="2025-05-11T09:00:00-03:00"),
        ev("b", 250, dia="2025-05-11"), ev("b", 250, dia="2025-05-11"),
    ]
    esperado, _ = rodar(eventos)
    for semente in range(20):
        embaralhado = eventos[:]
        random.Random(semente).shuffle(embaralhado)
        base, _ = rodar(embaralhado)
        assert base == esperado


# ----------------------------------------------------------------- versões
def test_vence_a_versao_com_atualizado_em_mais_recente():
    base, rel = rodar([
        ev("a", 15000, dia="2025-03-10", atualizado="2025-03-10T10:00:00-03:00"),
        ev("a", 15500, dia="2025-03-10", atualizado="2025-03-11T09:00:00-03:00"),
    ])
    assert total(base) == Decimal("15500.00")
    assert "versão substituída" in rel.por_categoria(DESCARTADO)[0].motivo


def test_versao_mais_recente_vence_mesmo_vindo_primeiro_no_arquivo():
    base, _ = rodar([
        ev("a", 15500, dia="2025-03-10", atualizado="2025-03-11T09:00:00-03:00"),
        ev("a", 15000, dia="2025-03-10", atualizado="2025-03-10T10:00:00-03:00"),
    ])
    assert total(base) == Decimal("15500.00")


def test_atualizado_em_compara_instantes_e_nao_texto():
    # 23h no UTC-3 do dia 10 (= 02h UTC do dia 11) é DEPOIS de 01h UTC do dia 11
    base, _ = rodar([
        ev("a", 100, atualizado="2025-05-11T01:00:00Z", dia="2025-05-10"),
        ev("a", 200, atualizado="2025-05-10T23:00:00-03:00", dia="2025-05-10"),
    ])
    assert total(base) == Decimal("200.00")


def test_versoes_diferentes_com_mesmo_atualizado_em_vao_para_duvida():
    base, rel = rodar([ev("a", 100), ev("a", 200)])
    assert base == []
    assert len(rel.por_categoria(DUVIDA)) == 2


# ----------------------------------------------------------------- estorno
def test_estorno_subtrai():
    base, _ = rodar([ev("a", 5000), ev("b", 5000, "estorno", dia="2025-05-11")])
    assert total(base) == Decimal("0.00")


def test_estorno_nao_e_somado_como_pagamento():
    base, _ = rodar([ev("a", 5000), ev("b", 1000, "estorno", dia="2025-05-11")])
    assert total(base) == Decimal("4000.00")


# ------------------------------------------- o que NÃO pode entrar nos totais
def test_valor_nulo_negativo_e_zero_ficam_fora_e_com_motivo():
    base, rel = rodar([ev("n", None), ev("neg", -200), ev("zero", 0), ev("ok", 10)])
    assert [e["evento_id"] for e in base] == ["ok"]
    assert {o.chave for o in rel.por_categoria(DUVIDA)} == {"n", "neg", "zero"}


def test_processo_vazio_ou_desconhecido_vai_para_duvida_e_nao_soma():
    base, rel = rodar([
        ev("vazio", processo=""),
        ev("desconhecido", processo="0099999-99.2020.8.26.0001"),
    ])
    assert base == []
    assert len(rel.por_categoria(DUVIDA)) == 2


def test_data_pagamento_depois_de_atualizado_em_vai_para_duvida():
    # "10/04/2025" lido como 10 de abril passa; se fosse 4 de outubro, seria futuro
    base, _ = rodar([ev("a", 10, dia="10/04/2025", atualizado="2025-04-10T09:00:00-03:00")])
    assert base[0]["pago_em"] == date(2025, 4, 10)
    base, rel = rodar([ev("b", 10, dia="2025-10-04", atualizado="2025-04-10T09:00:00-03:00")])
    assert base == [] and len(rel.por_categoria(DUVIDA)) == 1


def test_evento_sem_id_vai_para_duvida():
    base, rel = rodar([{**ev("x"), "evento_id": ""}])
    assert base == [] and len(rel.por_categoria(DUVIDA)) == 1


def test_processo_sem_mascara_soma_no_mesmo_precatorio():
    base, _ = rodar([ev("a", 100), ev("b", 50, processo=P1_NUM, dia="2025-05-11")])
    assert total(base) == Decimal("150.00")
    assert len({e["processo"] for e in base}) == 1
