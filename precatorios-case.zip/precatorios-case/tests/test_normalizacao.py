from datetime import date
from decimal import Decimal

import pytest

from precatorios.normalizacao import (
    DadoAmbiguo,
    DadoInvalido,
    chave_ente,
    dv_cnj_valido,
    formatar_processo,
    normalizar_processo,
    parse_data_local,
    parse_valor,
)
from precatorios.prazo import calcular_prazo


# ---------------------------------------------------------------- processo
def test_processo_com_e_sem_mascara_viram_a_mesma_chave():
    com = normalizar_processo("0023456-21.2020.8.26.0053")
    sem = normalizar_processo("00234562120208260053")
    assert com == sem == "00234562120208260053"


def test_processo_formatado_ida_e_volta():
    assert formatar_processo("00234562120208260053") == "0023456-21.2020.8.26.0053"


@pytest.mark.parametrize("ruim", ["", "   ", None, 123, "123", "0023456-21.2020.8.26.005X"])
def test_processo_invalido(ruim):
    with pytest.raises(DadoInvalido):
        normalizar_processo(ruim)


def test_dv_cnj_numero_real_de_exemplo():
    # 0000001-?? construído com a fórmula: DV = 98 - (N+AAAA+JTR+OOOO+"00") mod 97
    base = "0000001" + "2020" + "826" + "0001"
    dv = 98 - int(base + "00") % 97
    assert dv_cnj_valido(f"0000001{dv:02d}2020" + "8260001")
    assert not dv_cnj_valido("00000019920208260001")


# ------------------------------------------------------------------- valor
@pytest.mark.parametrize(
    "entrada, esperado, formato",
    [
        (15000.0, "15000.00", "numero"),
        (8000, "8000.00", "numero"),
        (Decimal("15500.0"), "15500.00", "numero"),
        ("2.500,50", "2500.50", "texto_ptbr"),
        ("45.000,00", "45000.00", "texto_ptbr"),
        ("1.234.567,89", "1234567.89", "texto_ptbr"),
        ("750,5", "750.50", "texto_ptbr"),
        ("1,234.56", "1234.56", "texto"),
        ("R$ 2.500,50", "2500.50", "texto_ptbr"),
        ("2500.5", "2500.50", "texto"),
    ],
)
def test_parse_valor_aceita_formatos_conhecidos(entrada, esperado, formato):
    valor, fmt = parse_valor(entrada)
    assert valor == Decimal(esperado)
    assert fmt == formato


def test_parse_valor_ptbr_nao_vira_centavos_errados():
    # o erro clássico: trocar só a vírgula e ficar com 2.50050
    assert parse_valor("2.500,50")[0] != Decimal("2.5005")


@pytest.mark.parametrize("ruim", [None, "", "abc", True, "1,2,3", "10,505", 12.345])
def test_parse_valor_recusa(ruim):
    with pytest.raises(DadoInvalido):
        parse_valor(ruim)


def test_parse_valor_recusa_ambiguo_em_vez_de_adivinhar():
    with pytest.raises(DadoAmbiguo):
        parse_valor("2.500")


def test_parse_valor_nao_perde_precisao_com_float_do_json():
    assert parse_valor(0.1)[0] + parse_valor(0.2)[0] == Decimal("0.30")


# -------------------------------------------------------------------- data
def test_data_iso_e_brasileira():
    assert parse_data_local("2025-03-10") == (date(2025, 3, 10), "iso")
    assert parse_data_local("10/04/2025") == (date(2025, 4, 10), "dd/mm/aaaa")


def test_data_utc_converte_para_brasilia_antes_de_pegar_a_data():
    # 01h UTC do dia 3 ainda é 22h do dia 2 em Brasília
    assert parse_data_local("2025-04-03T01:00:00Z")[0] == date(2025, 4, 2)


def test_data_com_offset_de_brasilia_mantem_o_dia():
    assert parse_data_local("2025-04-02T23:30:00-03:00")[0] == date(2025, 4, 2)


def test_data_com_offset_positivo_pode_mudar_o_dia():
    # 00h30 em UTC+2 = 19h30 do dia anterior em Brasília
    assert parse_data_local("2025-04-03T00:30:00+02:00")[0] == date(2025, 4, 2)


@pytest.mark.parametrize("ruim", [None, "", "2025-02-30", "31/02/2025", "ontem", 20250410])
def test_data_invalida(ruim):
    with pytest.raises(DadoInvalido):
        parse_data_local(ruim)


# ------------------------------------------------------------------- prazo
@pytest.mark.parametrize(
    "apresentado, prazo",
    [
        (date(2025, 4, 2), date(2026, 12, 31)),  # último dia: ano seguinte
        (date(2025, 4, 3), date(2027, 12, 31)),  # um dia depois: ano subsequente
        (date(2024, 2, 29), date(2025, 12, 31)),  # 29/02 de ano bissexto
        (date(2023, 12, 31), date(2025, 12, 31)),
        (date(2025, 1, 1), date(2026, 12, 31)),
        (date(2025, 12, 31), date(2027, 12, 31)),
    ],
)
def test_prazo(apresentado, prazo):
    assert calcular_prazo(apresentado) == prazo


def test_prazo_mesmo_instante_em_utc_e_em_brasilia_diverge_e_vale_brasilia():
    # Caso real dos dados: 0056789-54.2017.4.03.6100
    local, _ = parse_data_local("2025-04-03T01:00:00Z")
    assert calcular_prazo(local) == date(2026, 12, 31)
    assert calcular_prazo(date(2025, 4, 3)) == date(2027, 12, 31)  # o que o hub fez


# --------------------------------------------------------------------- ente
def test_chave_ente_ignora_caixa_acento_e_espacos():
    assert chave_ente("MUNICIPIO DE SAO PAULO") == chave_ente("  Município  de São Paulo ")


def test_chave_ente_distingue_entes_diferentes():
    assert chave_ente("União") != chave_ente("Município de Santos")
