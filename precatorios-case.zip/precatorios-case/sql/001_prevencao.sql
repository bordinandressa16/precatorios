-- Migração de prevenção. PostgreSQL 14+.
-- Parte do schema atual (case/schema.sql). Rodar em uma janela com a importação parada.
-- Tudo em uma transação: se qualquer passo falhar, nada muda.
BEGIN;

CREATE EXTENSION IF NOT EXISTS unaccent;

-- ---------------------------------------------------------------------------
-- 1. Entes devedores: uma linha por ente, com chave de comparação normalizada.
--    Hoje o ente é texto livre ("MUNICIPIO DE SAO PAULO" x "Município de São Paulo").
-- ---------------------------------------------------------------------------
CREATE TABLE ente_devedor (
    id               BIGSERIAL PRIMARY KEY,
    nome             TEXT NOT NULL,
    nome_normalizado TEXT NOT NULL UNIQUE,   -- sem acento, minúsculo, espaços colapsados
    CHECK (nome_normalizado = lower(unaccent(regexp_replace(btrim(nome), '\s+', ' ', 'g'))))
);

INSERT INTO ente_devedor (nome, nome_normalizado)
SELECT DISTINCT ON (k) regexp_replace(btrim(ente_devedor), '\s+', ' ', 'g'), k
FROM (SELECT ente_devedor,
             lower(unaccent(regexp_replace(btrim(ente_devedor), '\s+', ' ', 'g'))) AS k
      FROM precatorio) s
ORDER BY k, ente_devedor;

ALTER TABLE precatorio ADD COLUMN ente_id BIGINT REFERENCES ente_devedor (id);
UPDATE precatorio p SET ente_id = e.id
FROM ente_devedor e
WHERE e.nome_normalizado = lower(unaccent(regexp_replace(btrim(p.ente_devedor), '\s+', ' ', 'g')));
ALTER TABLE precatorio ALTER COLUMN ente_id SET NOT NULL;

-- ---------------------------------------------------------------------------
-- 2. Precatório: formato do processo garantido pelo banco, data de apresentação
--    e prazo calculado em UM só lugar (coluna gerada), na regra do dia 2 de abril.
-- ---------------------------------------------------------------------------
ALTER TABLE precatorio
    ADD CONSTRAINT precatorio_processo_20_digitos CHECK (numero_processo ~ '^[0-9]{20}$'),
    ADD CONSTRAINT precatorio_valor_face_positivo CHECK (valor_face > 0),
    -- DATE (sem hora): a data de calendário de Brasília, decidida na importação.
    ADD COLUMN apresentado_em DATE,
    ADD COLUMN prazo_pagamento DATE GENERATED ALWAYS AS (
        make_date(
            EXTRACT(YEAR FROM apresentado_em)::int
              + CASE WHEN apresentado_em <= make_date(EXTRACT(YEAR FROM apresentado_em)::int, 4, 2)
                     THEN 1 ELSE 2 END,
            12, 31)
    ) STORED;

-- Dígito verificador CNJ (mod 97). Útil com dados reais; não ligado como CHECK aqui
-- porque os números do case são fictícios e nenhum passa na conferência.
CREATE FUNCTION cnj_dv_valido(p TEXT) RETURNS BOOLEAN
LANGUAGE sql IMMUTABLE STRICT AS $$
    SELECT p ~ '^[0-9]{20}$'
       AND substr(p, 8, 2)::int =
           98 - ((substr(p, 1, 7) || substr(p, 10) || '00')::numeric % 97)::int
$$;

-- ---------------------------------------------------------------------------
-- 3. Controle de importação: cada arquivo é registrado pelo hash. O mesmo arquivo
--    não entra duas vezes; e as linhas recusadas ficam guardadas, não somem.
-- ---------------------------------------------------------------------------
CREATE TABLE importacao (
    id               BIGSERIAL PRIMARY KEY,
    arquivo          TEXT        NOT NULL,
    sha256           CHAR(64)    NOT NULL UNIQUE,
    recebido_em      TIMESTAMPTZ NOT NULL DEFAULT now(),
    eventos_lidos    INT         NOT NULL,
    eventos_gravados INT         NOT NULL,
    eventos_recusados INT        NOT NULL,
    -- cópias idênticas e versões antigas não são gravadas nem recusadas
    CHECK (eventos_gravados + eventos_recusados <= eventos_lidos)
);

CREATE TABLE pagamento_rejeitado (
    id            BIGSERIAL PRIMARY KEY,
    importacao_id BIGINT      NOT NULL REFERENCES importacao (id),
    evento_id     TEXT,
    payload       JSONB       NOT NULL,          -- o evento exatamente como chegou
    motivo        TEXT        NOT NULL,
    situacao      TEXT        NOT NULL DEFAULT 'pendente'
                  CHECK (situacao IN ('pendente', 'resolvido', 'descartado')),
    criado_em     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON pagamento_rejeitado (situacao) WHERE situacao = 'pendente';

-- ---------------------------------------------------------------------------
-- 4. Pagamento: evento_id único (idempotência), versão do evento e origem.
-- ---------------------------------------------------------------------------
-- 4a. Preserva e remove duplicatas já existentes ANTES de criar a unicidade.
--     Mantém a linha de maior id (importada por último). Confira o backup antes de
--     confiar nisso: se houver duplicatas com valores diferentes, decidir com o tribunal.
CREATE TABLE pagamento_duplicado_backup AS
SELECT * FROM pagamento
WHERE evento_id IN (SELECT evento_id FROM pagamento GROUP BY evento_id HAVING count(*) > 1);

DELETE FROM pagamento a USING pagamento b
WHERE a.evento_id = b.evento_id AND a.id < b.id;

ALTER TABLE pagamento
    ADD COLUMN atualizado_em  TIMESTAMPTZ,       -- NULL só nas linhas antigas
    ADD COLUMN importacao_id  BIGINT REFERENCES importacao (id),
    ADD CONSTRAINT pagamento_evento_id_uk UNIQUE (evento_id);

-- ---------------------------------------------------------------------------
-- 5. O total pago deixa de ser um acumulador e vira consulta: não há valor para
--    "somar duas vezes". Pagamento soma, estorno subtrai.
-- ---------------------------------------------------------------------------
CREATE VIEW precatorio_total_pago AS
SELECT p.id AS precatorio_id,
       p.numero_processo,
       p.valor_face,
       COALESCE(SUM(CASE g.tipo WHEN 'pagamento' THEN g.valor
                                WHEN 'estorno'   THEN -g.valor END), 0)::numeric(15,2) AS total_pago
FROM precatorio p
LEFT JOIN pagamento g ON g.precatorio_id = p.id
GROUP BY p.id, p.numero_processo, p.valor_face;

COMMIT;

-- ===========================================================================
-- Como o script de importação deve gravar (exemplo, não faz parte da migração).
-- Uma transação por arquivo; reexecutar o mesmo arquivo não muda nada.
--
--   BEGIN;
--   INSERT INTO importacao (arquivo, sha256, eventos_lidos, eventos_gravados, eventos_recusados)
--   VALUES (:arquivo, :sha256, :lidos, :gravados, :recusados);       -- falha se o hash já existe
--
--   INSERT INTO pagamento (precatorio_id, evento_id, tipo, valor, pago_em, atualizado_em, importacao_id)
--   VALUES (...)
--   ON CONFLICT (evento_id) DO UPDATE
--     SET tipo = EXCLUDED.tipo, valor = EXCLUDED.valor, pago_em = EXCLUDED.pago_em,
--         atualizado_em = EXCLUDED.atualizado_em, importacao_id = EXCLUDED.importacao_id
--     WHERE pagamento.atualizado_em IS NULL
--        OR EXCLUDED.atualizado_em > pagamento.atualizado_em;        -- só versão mais nova vence
--
--   INSERT INTO pagamento_rejeitado (importacao_id, evento_id, payload, motivo) VALUES (...);
--   COMMIT;
--
--   -- e depois: se houver rejeitados pendentes, avisar a operação (e-mail/Slack) e falhar o job.
-- ===========================================================================
