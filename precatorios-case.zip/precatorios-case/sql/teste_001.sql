-- Teste de fumaça da migração 001. Rodar em banco DESCARTÁVEL, depois de aplicar
-- case/schema.sql e sql/001_prevencao.sql. Tudo é desfeito no final (ROLLBACK).
--   psql -v ON_ERROR_STOP=1 -d scratch -f sql/teste_001.sql
BEGIN;

INSERT INTO ente_devedor (nome, nome_normalizado) VALUES ('Teste', 'teste');
INSERT INTO precatorio (numero_processo, ente_devedor, valor_face, ente_id, apresentado_em)
SELECT '99999999999999999991', 'Teste', 100, id, DATE '2025-04-02' FROM ente_devedor WHERE nome_normalizado = 'teste';
INSERT INTO precatorio (numero_processo, ente_devedor, valor_face, ente_id, apresentado_em)
SELECT '99999999999999999992', 'Teste', 100, id, DATE '2025-04-03' FROM ente_devedor WHERE nome_normalizado = 'teste';
INSERT INTO precatorio (numero_processo, ente_devedor, valor_face, ente_id, apresentado_em)
SELECT '99999999999999999993', 'Teste', 100, id, DATE '2024-02-29' FROM ente_devedor WHERE nome_normalizado = 'teste';

DO $$
DECLARE
    pid BIGINT;
BEGIN
    -- prazo: 2 de abril ainda é "ano seguinte"; 3 de abril já é "ano subsequente"; 29/02 ok
    ASSERT (SELECT prazo_pagamento FROM precatorio WHERE numero_processo = '99999999999999999991') = DATE '2026-12-31';
    ASSERT (SELECT prazo_pagamento FROM precatorio WHERE numero_processo = '99999999999999999992') = DATE '2027-12-31';
    ASSERT (SELECT prazo_pagamento FROM precatorio WHERE numero_processo = '99999999999999999993') = DATE '2025-12-31';

    SELECT id INTO pid FROM precatorio WHERE numero_processo = '99999999999999999991';

    -- upsert por versão: reenvio idêntico e versão antiga não mudam nada; versão nova vence
    INSERT INTO pagamento (precatorio_id, evento_id, tipo, valor, pago_em, atualizado_em)
    VALUES (pid, 'ev-t1', 'pagamento', 15000, DATE '2025-03-10', TIMESTAMPTZ '2025-03-10 10:00-03');
    FOR i IN 1..2 LOOP  -- o mesmo evento chega duas vezes
        INSERT INTO pagamento (precatorio_id, evento_id, tipo, valor, pago_em, atualizado_em)
        VALUES (pid, 'ev-t1', 'pagamento', 15000, DATE '2025-03-10', TIMESTAMPTZ '2025-03-10 10:00-03')
        ON CONFLICT (evento_id) DO UPDATE SET valor = EXCLUDED.valor, atualizado_em = EXCLUDED.atualizado_em
        WHERE pagamento.atualizado_em IS NULL OR EXCLUDED.atualizado_em > pagamento.atualizado_em;
    END LOOP;
    ASSERT (SELECT total_pago FROM precatorio_total_pago WHERE precatorio_id = pid) = 15000, 'reenvio somou duas vezes';

    INSERT INTO pagamento (precatorio_id, evento_id, tipo, valor, pago_em, atualizado_em)
    VALUES (pid, 'ev-t1', 'pagamento', 15500, DATE '2025-03-10', TIMESTAMPTZ '2025-03-11 09:00-03')
    ON CONFLICT (evento_id) DO UPDATE SET valor = EXCLUDED.valor, atualizado_em = EXCLUDED.atualizado_em
    WHERE pagamento.atualizado_em IS NULL OR EXCLUDED.atualizado_em > pagamento.atualizado_em;
    ASSERT (SELECT total_pago FROM precatorio_total_pago WHERE precatorio_id = pid) = 15500, 'versão nova não venceu';

    INSERT INTO pagamento (precatorio_id, evento_id, tipo, valor, pago_em, atualizado_em)
    VALUES (pid, 'ev-t1', 'pagamento', 1, DATE '2025-03-10', TIMESTAMPTZ '2025-03-09 09:00-03')
    ON CONFLICT (evento_id) DO UPDATE SET valor = EXCLUDED.valor, atualizado_em = EXCLUDED.atualizado_em
    WHERE pagamento.atualizado_em IS NULL OR EXCLUDED.atualizado_em > pagamento.atualizado_em;
    ASSERT (SELECT total_pago FROM precatorio_total_pago WHERE precatorio_id = pid) = 15500, 'versão antiga sobrescreveu';

    -- estorno subtrai
    INSERT INTO pagamento (precatorio_id, evento_id, tipo, valor, pago_em, atualizado_em)
    VALUES (pid, 'ev-t2', 'estorno', 500, DATE '2025-03-12', TIMESTAMPTZ '2025-03-12 10:00-03');
    ASSERT (SELECT total_pago FROM precatorio_total_pago WHERE precatorio_id = pid) = 15000, 'estorno não subtraiu';

    -- processo com máscara é recusado pelo banco
    BEGIN
        INSERT INTO precatorio (numero_processo, ente_devedor, valor_face, ente_id)
        VALUES ('0012345-10.2019.8.26.0053', 'x', 1, (SELECT id FROM ente_devedor LIMIT 1));
        ASSERT false, 'processo com máscara foi aceito';
    EXCEPTION WHEN string_data_right_truncation OR check_violation THEN NULL;
    END;
END $$;

ROLLBACK;
\echo 'teste_001: OK'
